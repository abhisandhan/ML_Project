print(x.shape[2])
