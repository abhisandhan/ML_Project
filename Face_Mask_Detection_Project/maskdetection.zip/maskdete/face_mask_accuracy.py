import numpy as np
import cv2
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix

with_mask = np.load('with_mask.npy')
without_mask = np.load('without_mask.npy')

# print(with_mask.shape)
# print(without_mask.shape)

with_mask = with_mask.reshape(200, 50 * 50 * 3)
without_mask = without_mask.reshape(200, 50 * 50 * 3)

# print(with_mask.shape)

x = np.r_[with_mask, without_mask]
# print(x.shape[2])

labels = np.zeros(x.shape[0])
labels[200:] = 1.0

names = {0: 'Mask', 1: 'No mask'}

x_train, x_test, y_train, y_test = train_test_split(x, labels, test_size=0.25)

# print(x_train.shape)
pca = PCA(n_components=3)
x_train = pca.fit_transform(x_train)

# print(x_train[0])
# print(x_train.shape)

x_train, x_test, y_train, y_test = train_test_split(x, labels, test_size=0.22)
svm = SVC()
svm.fit(x_train, y_train)
# x_test = pca.transform(x_test)
y_pred = svm.predict(x_test)

# print(x_test.shape)

print(accuracy_score(y_test, y_pred))

clf_model = DecisionTreeClassifier()
clf_model.fit(x_train, y_train)
y_predict = clf_model.predict(x_test)
print(accuracy_score(y_test, y_predict))

lr = LogisticRegression()
lr.fit(x_train, y_train)
predictions = lr.predict(x_test)
print(accuracy_score(y_test, predictions))
