import cv2
import numpy as np
import matplotlib.pyplot as plt

haar_data = cv2.CascadeClassifier(
    "C:\haar-cascade-files-master\haarcascade_frontalface_default.xml")
data = []

capture = cv2.VideoCapture(0)
while True:
    flag, img = capture.read()
    if flag:

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = haar_data.detectMultiScale(gray)
        # print(faces)
        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 255), (4))
            face = img[y:y+h, x:x+w, :]
            face = cv2.resize(face, (50, 50))
            print(len(data))
            if len(data) < 200:
                data.append(face)

    cv2.imshow('result', img)
    if cv2.waitKey(2) == 27 or len(data) >= 200:
        break


cv2.destroyAllWindows()

#np.save('without_mask.npy', data)
#np.save('with_mask.npy', data)
plt.imshow(data[0])
