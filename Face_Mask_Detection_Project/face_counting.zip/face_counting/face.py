import mediapipe as mp
import cv2

mp_drawing = mp.solutions.drawing_utils
mp_holistic = mp.solutions.holistic

face_drawing_spec = mp_drawing.DrawingSpec(color=(0,255,0),thickness=1,circle_radius=1)
face_drawing_spec1 = mp_drawing.DrawingSpec(color=(0,255,0),thickness=1,circle_radius=1)
hand_drawing_spec = mp_drawing.DrawingSpec(color=(255,0,255),thickness=2,circle_radius=2)
hand_drawing_spec1 = mp_drawing.DrawingSpec(color=(255,0,0),thickness=2,circle_radius=2)

cam = cv2.VideoCapture(0)

# Initialize Holistic Model
with mp_holistic.Holistic(min_detection_confidence=0.35, min_tracking_confidence=0.5) as holistic:

    while cam.isOpened():
        ret, frame = cam.read()
        
        cv2.imshow('Raw Webcam Feed',  frame)
        
        # Change color format
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Make detection
        result = holistic.process(image)
        
        #Rechange color format
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        
        # Draw  Face landmarks
        mp_drawing.draw_landmarks(image, result.face_landmarks, mp_holistic.FACEMESH_CONTOURS,face_drawing_spec,face_drawing_spec1)
        
        # Draw  Right Hand landmarks
        mp_drawing.draw_landmarks(image, result.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS,hand_drawing_spec,hand_drawing_spec1)
        
        # Draw  Left Hand landmarks
        mp_drawing.draw_landmarks(image, result.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS,hand_drawing_spec,hand_drawing_spec1)
        
        # Draw  Pose landmarks
        mp_drawing.draw_landmarks(image, result.pose_landmarks, mp_holistic.POSE_CONNECTIONS)
        
        
        cv2.imshow('Holistic Model Detection',  image)

        if cv2.waitKey(10) & 0xFF == ord('q'):
            break


cv2.destroyAllWindows()
